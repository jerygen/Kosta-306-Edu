package ex0203.homework;

public class Homework01 {

	public static void main(String[] args) {
		String name = "미연";
		int kor, eng, mat, total;
		double avg;
		char grade;
		
		kor = (int)(Math.random()*56 + 45);
		eng = (int)(Math.random()*56 + 45);
		mat = (int)(Math.random()*56 + 45);
		
		total = kor + eng + mat;
		avg = total/3.0;
		
		// if문
//		if(avg >= 90) grade = 'A';
//		else if(avg >= 80) grade = 'B';
//		else if(avg >= 70) grade = 'C';
//		else if(avg >= 60) grade = 'D';
//		else score = 'E';
		
		
		//switch문	
		switch((int)avg) {
		case 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100 -> grade = 'A';
		case 80, 81, 82, 83, 84, 85, 86, 87, 88, 89 -> grade = 'B';
		case 70, 71, 72, 73, 74, 75, 76, 77, 78, 79 -> grade = 'C';
		case 60, 61, 62, 63, 64, 65, 66, 67, 68, 69 -> grade = 'D';
		default -> grade = 'F';
		}
		
		System.out.println(name+"님 성적표");
		System.out.println("국어: "+kor+"점");
		System.out.println("영어: "+eng+"점");
		System.out.println("수학: "+mat+"점");
		System.out.println("총점: "+total+"점");
		System.out.println("평균: "+avg+"점");
		System.out.println("등급: "+grade);
	}

}

package ex0203.homework;

public class Homework03 {

	public static void main(String[] args) {
		int value = 356;
		System.out.println(value-56);

	}

}

package ex0203.homework;

public class Homework08 {

	public static void main(String[] args) {
		int x = 1;
		int y = 1;
		
		
		for(x=1; x<=10; x++) {
			for(y=1; y<=10; y++) {
				int sum = 4*x + 5*y;
				if(sum == 60) System.out.println("("+x+","+y+")");
			}
		}
		
	}

}

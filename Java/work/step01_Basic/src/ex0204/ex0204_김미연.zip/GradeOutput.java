package ex0204.homework;

import java.util.Scanner;

class CalculateGrade {
	private int total(int kor, int eng, int math) {
		int sum = kor + eng + math;
		return sum;
	}

	
	private double average(int sum, int j) {
		double avg = (int)(sum/j*100)*0.01;
		return avg;
	}
	
	private char grade(double avg) {
		char result = switch((int)avg/10) {
		case 9, 10 -> 'A';
		case 8 -> 'B';
		case 7 -> 'C';
		case 6 -> 'D';
		default -> 'F';
		};
		return result;
	}
	
	public void output(int kor, int eng, int math) {
		CalculateGrade cg = new CalculateGrade();
		int sum = cg.total(kor, eng, math);
		double avg = cg.average(sum, 3);
		char grade = cg.grade(avg);
		
		System.out.println("총점: "+sum);
		System.out.println("평균: "+avg);
		System.out.println("등급: "+grade);
	}
}

public class GradeOutput{
	public static void main(String [] args) {
		CalculateGrade res = new CalculateGrade();
		
		boolean run = true;
		Scanner sc = new Scanner(System.in);
		
		while(run) {
			System.out.println("\n---------------------");
			System.out.println("1. 성적표 구하기 | 2. 종료" );
			System.out.println("---------------------");
			System.out.print("선택> ");
			
			int choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.print("국어 점수> ");
				int kor = sc.nextInt();
				System.out.print("영어 점수> ");
				int eng = sc.nextInt();
				System.out.print("수학 점수> ");
				int math = sc.nextInt();
				
				res.output(kor, eng, math);
				break;				
			case 2:
				System.out.println("프로그램 종료");
				run = false;
				break;
			default: 
				System.out.println("1 또는 2만 입력하세요.");
				break;
			}
			
		}
		
	}
}
